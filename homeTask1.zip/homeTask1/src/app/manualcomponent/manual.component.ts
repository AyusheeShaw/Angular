import { Component } from '@angular/core';
@Component({
  selector: 'manual-component',
  templateUrl: './manual.component.html',
  styleUrls: ['./manual.component.css'],
})
export class ManualComponent {}
